<?php
// post-login router: read roles from Keycloak token via mod_auth_openidc injected claims
header('Cache-Control: no-store');

function landing_for_roles(array $roles) {
  $priority = ['admin' => '/landing/admin.html',
               'manufacture' => '/landing/manufacture.html',
               'employee' => '/landing/employee.html',
               'guest' => '/landing/guest.html'];
  foreach ($priority as $role => $path) {
    if (in_array($role, $roles, true)) return $path;
  }
  return '/landing/guest.html';
}

// mod_auth_openidc exposes claims as env vars/headers like OIDC_CLAIM_realm_access containing JSON
$realm_access_json = $_SERVER['OIDC_CLAIM_realm_access'] ?? '';
$roles = [];

if ($realm_access_json) {
  $decoded = json_decode($realm_access_json, true);
  if (json_last_error() === JSON_ERROR_NONE && isset($decoded['roles']) && is_array($decoded['roles'])) {
    $roles = $decoded['roles'];
  }
}

// fallback: some setups map roles into OIDC_CLAIM_roles as a CSV or array-like string
if (!$roles && isset($_SERVER['OIDC_CLAIM_roles'])) {
  $raw = $_SERVER['OIDC_CLAIM_roles'];
  if (is_string($raw)) {
    // naive split by comma/space
    $roles = array_values(array_filter(array_map('trim', preg_split('/[\s,]+/', $raw))));
  }
}

// Destination based on roles
$dest = landing_for_roles($roles);

// Example: expose the username
$user = $_SERVER['REMOTE_USER'] ?? 'unknown';

// If you want to inspect all headers uncomment:
// print_r(apache_request_headers()); exit;

header("Location: " . $dest . "?u=" . urlencode($user));
exit;
?>
