# Keycloak × Apache (mod_auth_openidc) Demo

This bundle gives you a **simple, working** role‑based login with Keycloak and an Apache website.

## What you get
- A Keycloak realm **FactoryRealm** with roles: `admin`, `manufacture`, `employee`, `guest`
- A confidential OIDC client **apache-site** for Apache (mod_auth_openidc)
- Demo users: `admin1`, `manuf1`, `emp1`, `guest1` (password: `Passw0rd!`)
- A simple site with landing pages automatically chosen by role

## Quick start (Ubuntu/Debian)
```bash
sudo bash keycloak-setup.sh
```
> The script installs Java 21, PostgreSQL, Apache + mod_auth_openidc, and Keycloak 26.3.x (dev mode for demo).

1. Copy **site/** to `/var/www/factory-site`:
```bash
sudo mkdir -p /var/www/factory-site
sudo rsync -av site/ /var/www/factory-site/
```

2. Put `apache/vhost-factory.conf` into `/etc/apache2/sites-available/factory.conf`. Edit:
   - Replace `YOUR_DOMAIN` with your server name or IP (e.g. `server.example.com` or `10.0.0.5`).
   - Set `OIDCClientSecret` to the value stored at `/root/keycloak_apache_client_secret.txt` (created by the setup script).

3. Enable site + modules and reload Apache:
```bash
sudo a2enmod auth_openidc headers proxy proxy_http rewrite php*
sudo a2ensite factory
sudo systemctl reload apache2
```

4. Visit: `http://YOUR_DOMAIN/` and click **Login**. You’ll be routed to the landing page based on role.

## Notes
- This is a **demo** setup using `kc.sh start-dev` (HTTP on 127.0.0.1:8080). For production, terminate TLS, set `--hostname`, and use `kc.sh build` + `start` with proper DB and proxy settings.
- The role routing happens in `site/post-login.php` by reading `OIDC_CLAIM_realm_access` injected by mod_auth_openidc.
- To logout, the landing pages link to `/secure/redirect_uri?logout=/loggedout.html`.

## Versions
- Keycloak: 26.3.x
- mod_auth_openidc: use distro package or latest release.
