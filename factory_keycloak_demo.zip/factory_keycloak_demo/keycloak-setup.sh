#!/usr/bin/env bash
set -euo pipefail

# ---------- SETTINGS ----------
# Change these before running in production
KC_VERSION="${KC_VERSION:-26.3.1}"
KC_HOME="/opt/keycloak"
KC_USER="keycloak"
KC_HTTP_PORT="${KC_HTTP_PORT:-8080}"
SITE_DOMAIN="${SITE_DOMAIN:-YOUR_DOMAIN}"
REALM="${REALM:-FactoryRealm}"
CLIENT_ID="${CLIENT_ID:-apache-site}"
# Will be set in Keycloak and reused in Apache vhost
CLIENT_SECRET_FILE="/root/keycloak_apache_client_secret.txt"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-Admin123!}"
DB_NAME="${DB_NAME:-keycloak}"
DB_USER="${DB_USER:-kcuser}"
DB_PASS="${DB_PASS:-kcp@ss}"
# ------------------------------

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y wget tar unzip jq \
  openjdk-21-jdk postgresql \
  apache2 libapache2-mod-auth-openidc libapache2-mod-php php php-cli

# Create Postgres DB
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 || sudo -u postgres createdb "${DB_NAME}"
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" | grep -q 1 || sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}'"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER}"
# Ensure privileges on future schemas
sudo -u postgres psql -d "${DB_NAME}" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO ${DB_USER};"

# Install Keycloak
if [ ! -d "${KC_HOME}" ]; then
  wget -O /tmp/keycloak.tar.gz "https://github.com/keycloak/keycloak/releases/download/${KC_VERSION}/keycloak-${KC_VERSION}.tar.gz"
  mkdir -p "${KC_HOME}"
  tar -xzf /tmp/keycloak.tar.gz --strip-components=1 -C "${KC_HOME}"
  useradd --system --home "${KC_HOME}" --shell /sbin/nologin "${KC_USER}" || true
  chown -R ${KC_USER}:${KC_USER} "${KC_HOME}"
fi

# Create systemd service (dev mode for demo)
cat >/etc/systemd/system/keycloak.service <<EOF
[Unit]
Description=Keycloak ${KC_VERSION}
After=network.target

[Service]
Type=exec
User=${KC_USER}
WorkingDirectory=${KC_HOME}
Environment=KEYCLOAK_ADMIN=${ADMIN_USER}
Environment=KEYCLOAK_ADMIN_PASSWORD=${ADMIN_PASS}
Environment=KC_DB=postgres
Environment=KC_DB_URL=jdbc:postgresql://127.0.0.1:5432/${DB_NAME}
Environment=KC_DB_USERNAME=${DB_USER}
Environment=KC_DB_PASSWORD=${DB_PASS}
# Simplify demo: HTTP only on localhost:8080; not for production
ExecStart=${KC_HOME}/bin/kc.sh start-dev --http-enabled=true --http-port=${KC_HTTP_PORT} --hostname-strict=false
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now keycloak

# Wait for KC to be up
echo "Waiting for Keycloak to start on port ${KC_HTTP_PORT}..."
for i in {1..60}; do
  if curl -sf "http://127.0.0.1:${KC_HTTP_PORT}" >/dev/null; then break; fi
  sleep 2
done

# Configure realm, roles, client, users using kcadm.sh
${KC_HOME}/bin/kcadm.sh config credentials --server "http://127.0.0.1:${KC_HTTP_PORT}" --realm master --user "${ADMIN_USER}" --password "${ADMIN_PASS}"

# Realm
if ! ${KC_HOME}/bin/kcadm.sh get realms/${REALM} >/dev/null 2>&1; then
  ${KC_HOME}/bin/kcadm.sh create realms -s realm="${REALM}" -s enabled=true
fi

# Roles
for role in admin manufacture employee guest; do
  ${KC_HOME}/bin/kcadm.sh create roles -r "${REALM}" -s name="${role}" >/dev/null 2>&1 || true
done

# Client (confidential)
CLIENT_JSON=$(cat <<JSON
{ "clientId": "${CLIENT_ID}",
  "protocol": "openid-connect",
  "enabled": true,
  "publicClient": false,
  "standardFlowEnabled": true,
  "directAccessGrantsEnabled": false,
  "serviceAccountsEnabled": false,
  "redirectUris": ["http://${SITE_DOMAIN}/secure/redirect_uri","http://${SITE_DOMAIN}/oidc/callback","http://${SITE_DOMAIN}/*"],
  "webOrigins": ["http://${SITE_DOMAIN}"],
  "attributes": {
    "post.logout.redirect.uris": "+",
    "pkce.code.challenge.method": "S256"
  }
}
JSON
)
# create or update
if ! ${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="${CLIENT_ID}" | jq -e '.[0].id' >/dev/null; then
  ${KC_HOME}/bin/kcadm.sh create clients -r "${REALM}" -f <(echo "${CLIENT_JSON}")
fi

CLIENT_UUID=$(${KC_HOME}/bin/kcadm.sh get clients -r "${REALM}" -q clientId="${CLIENT_ID}" | jq -r '.[0].id')
# Ensure secret exists
SECRET_JSON=$(${KC_HOME}/bin/kcadm.sh get clients/${CLIENT_UUID}/client-secret -r "${REALM}")
CLIENT_SECRET=$(echo "${SECRET_JSON}" | jq -r '.value')
if [ -z "${CLIENT_SECRET}" ] || [ "${CLIENT_SECRET}" = "null" ]; then
  CLIENT_SECRET=$(${KC_HOME}/bin/kcadm.sh create clients/${CLIENT_UUID}/client-secret -r "${REALM}" -i | tr -d '\r\n')
  # creation returns empty; fetch again
  CLIENT_SECRET=$(${KC_HOME}/bin/kcadm.sh get clients/${CLIENT_UUID}/client-secret -r "${REALM}" | jq -r '.value')
fi
echo -n "${CLIENT_SECRET}" > "${CLIENT_SECRET_FILE}"
chmod 600 "${CLIENT_SECRET_FILE}"
echo "Client secret written to ${CLIENT_SECRET_FILE}"

# Demo users
create_user () { # username role
  local U="$1"; local ROLE="$2"
  if ! ${KC_HOME}/bin/kcadm.sh get users -r "${REALM}" -q username="${U}" | jq -e '.[0].id' >/dev/null; then
    ${KC_HOME}/bin/kcadm.sh create users -r "${REALM}" -s username="${U}" -s enabled=true
    UID=$(${KC_HOME}/bin/kcadm.sh get users -r "${REALM}" -q username="${U}" | jq -r '.[0].id')
    ${KC_HOME}/bin/kcadm.sh update users/${UID}/reset-password -r "${REALM}" -s type=password -s value="Passw0rd!" -s temporary=false
    ROLE_ID=$(${KC_HOME}/bin/kcadm.sh get roles -r "${REALM}" | jq -r '.[] | select(.name=="'${ROLE}'") | .id')
    ${KC_HOME}/bin/kcadm.sh add-roles -r "${REALM}" --uusername "${U}" --rolename "${ROLE}"
  fi
}
create_user admin1 admin
create_user manuf1 manufacture
create_user emp1 employee
create_user guest1 guest

echo "=== DONE ==="
echo "Keycloak admin:  http://127.0.0.1:${KC_HTTP_PORT}  user=${ADMIN_USER} pass=${ADMIN_PASS}"
echo "Realm: ${REALM} | Client: ${CLIENT_ID} | Secret: $(cat ${CLIENT_SECRET_FILE})"
echo "Remember to update Apache vhost with OIDCClientSecret from ${CLIENT_SECRET_FILE} and set ServerName to ${SITE_DOMAIN}."
